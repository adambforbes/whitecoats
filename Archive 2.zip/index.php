<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        
        <?php
        // put your code here
        
        echo "Retrieving staff record for Adam...";
        echo "<br><br>";
        
        //local hosted db
         $link = mysql_connect(
         ':/Applications/MAMP/tmp/mysql/mysql.sock',
         'root',
         'root'
        );
        
        //AWS DB
        // $link = mysql_connect(
        // 'blackmamba.cm3fn0yhwehj.us-east-1.rds.amazonaws.com',
        // 'adamforbes',
        // 'blackmamba'
        // );
        
        
        if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
        
        mysql_select_db('blackmamba');
        
                
        $query = "SELECT * FROM Persons";
        
        $result = mysql_query($query);
        
        if (!$result) {
            $message  = 'Invalid query: ' . mysql_error() . "\n";
            $message .= 'Whole query: ' . $query;
            die($message);
        }
         while ($row = mysql_fetch_assoc($result)) {
            echo $row['PersonID'];
            echo "<br><br>";
            echo $row['LastName'];
            echo "<br><br>";
            echo $row['Address'];
            echo "<br><br>";
            echo $row['City'];
         }
        ?>
        
        
    </body>
</html>
